/* Core PDF viewer. PDF.js is loaded by reader.html. */
let pdfDoc=null,currentPage=1,scale=1.15,allPageText=[];
const canvas=document.getElementById("pdfCanvas"),ctx=canvas.getContext("2d");
const pageContainer=document.getElementById("pageContainer"),message=document.getElementById("message");
const pageNumber=document.getElementById("pageNumber"),pageCount=document.getElementById("pageCount");
const textLayer=document.getElementById("textLayer");
window.OpenPDF={get pdf(){return pdfDoc},get page(){return currentPage},get text(){return allPageText}};
async function loadPdf(fileOrUrl,name){
  if(!window.pdfjsLib){message.textContent="PDF.js could not load. Check your internet connection, then reload.";return;}
  try{
    message.textContent="Loading PDF…";
    let task;
    if(fileOrUrl instanceof File){task=pdfjsLib.getDocument({data:await fileOrUrl.arrayBuffer()});}
    else{task=pdfjsLib.getDocument(fileOrUrl);}
    pdfDoc=await task.promise;currentPage=1;allPageText=Array(pdfDoc.numPages).fill("");
    document.getElementById("fileTitle").textContent=name||"PDF document";
    pageCount.textContent="/ "+pdfDoc.numPages;pageNumber.max=pdfDoc.numPages;
    pageContainer.hidden=false;message.hidden=true;
    await renderPage(currentPage);extractAllText();
    document.dispatchEvent(new Event("pdf-loaded"));
  }catch(err){console.error(err);message.hidden=false;message.textContent="Could not open this PDF. It may be damaged, password-protected, or unsupported.";}
}
async function renderPage(num){
  if(!pdfDoc)return;
  currentPage=Math.max(1,Math.min(pdfDoc.numPages,num));pageNumber.value=currentPage;
  const page=await pdfDoc.getPage(currentPage),viewport=page.getViewport({scale});
  const dpr=window.devicePixelRatio||1;
  canvas.width=Math.floor(viewport.width*dpr);canvas.height=Math.floor(viewport.height*dpr);
  canvas.style.width=viewport.width+"px";canvas.style.height=viewport.height+"px";
  textLayer.style.width=viewport.width+"px";textLayer.style.height=viewport.height+"px";
  await page.render({canvasContext:ctx,viewport, transform:dpr!==1?[dpr,0,0,dpr,0,0]:null}).promise;
  textLayer.innerHTML="";
  const content=await page.getTextContent();
  content.items.forEach(item=>{
    if(!item.str)return;
    const tx=pdfjsLib.Util.transform(viewport.transform,item.transform);
    const span=document.createElement("span");span.textContent=item.str;
    span.style.left=tx[4]+"px";span.style.top=(tx[5]-item.height*scale)+"px";
    span.style.fontSize=Math.max(1,item.height*scale)+"px";
    span.style.fontFamily=item.fontName||"sans-serif";
    textLayer.appendChild(span);
  });
  document.getElementById("zoomLabel").textContent=Math.round(scale*100)+"%";
}
async function extractAllText(){
  for(let i=1;i<=pdfDoc.numPages;i++){
    const p=await pdfDoc.getPage(i),c=await p.getTextContent();
    allPageText[i-1]=c.items.map(x=>x.str).join(" ");
  }
  document.dispatchEvent(new Event("pdf-text-ready"));
}
document.getElementById("prevPage").onclick=()=>renderPage(currentPage-1);
document.getElementById("nextPage").onclick=()=>renderPage(currentPage+1);
pageNumber.addEventListener("change",()=>renderPage(Number(pageNumber.value)||1));
document.getElementById("zoomIn").onclick=()=>{scale=Math.min(3,scale+.15);renderPage(currentPage)};
document.getElementById("zoomOut").onclick=()=>{scale=Math.max(.5,scale-.15);renderPage(currentPage)};
document.getElementById("replacePdf").addEventListener("change",e=>{if(e.target.files[0])loadPdf(e.target.files[0],e.target.files[0].name)});
const savedUrl=sessionStorage.getItem("openPdfUrl");
if(savedUrl)loadPdf(savedUrl,sessionStorage.getItem("openPdfName"));
