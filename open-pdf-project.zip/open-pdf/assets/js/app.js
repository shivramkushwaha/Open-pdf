const input=document.getElementById("pdfInput");
input.addEventListener("change",()=>{
  const file=input.files[0]; if(!file)return;
  if(file.type!=="application/pdf"&&!file.name.toLowerCase().endsWith(".pdf")){alert("Please choose a PDF file.");return;}
  const url=URL.createObjectURL(file);
  sessionStorage.setItem("openPdfUrl",url);
  sessionStorage.setItem("openPdfName",file.name);
  window.location.href="reader.html";
});
