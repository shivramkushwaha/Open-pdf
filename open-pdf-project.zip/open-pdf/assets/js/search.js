const searchInput=document.getElementById("searchInput"),searchResults=document.getElementById("searchResults");
function runSearch(){
  const q=searchInput.value.trim().toLowerCase();searchResults.innerHTML="";
  if(!q){searchResults.textContent="Enter a word or phrase to search.";return;}
  if(!window.OpenPDF.pdf){searchResults.textContent="Open a PDF first.";return;}
  const hits=[];
  window.OpenPDF.text.forEach((txt,i)=>{let at=-1,start=0;while((at=txt.toLowerCase().indexOf(q,start))!==-1){hits.push({page:i+1,index:at,context:txt.slice(Math.max(0,at-65),Math.min(txt.length,at+q.length+90))});start=at+q.length;}});
  searchResults.textContent=hits.length?`${hits.length} match(es) found.`:"No matches found.";
  hits.slice(0,100).forEach(hit=>{const el=document.createElement("button");el.className="item-card";el.style.display="block";el.style.width="100%";el.style.textAlign="left";el.textContent=`Page ${hit.page}: …${hit.context}…`;el.onclick=()=>window.dispatchEvent(new CustomEvent("open-pdf-page",{detail:hit.page}));searchResults.appendChild(el)});
}
document.getElementById("searchButton").onclick=runSearch;
searchInput.addEventListener("keydown",e=>{if(e.key==="Enter")runSearch()});
window.addEventListener("open-pdf-page",e=>window.OpenPDF.pdf&&window.OpenPDF.pdf.getPage(e.detail).then(()=>document.getElementById("pageNumber").value=e.detail).then(()=>document.getElementById("pageNumber").dispatchEvent(new Event("change"))));
