/* Notes are stored in localStorage, per document name. */
const docKey=()=> "openpdf-notes-"+(document.getElementById("fileTitle").textContent||"document");
function getNotes(){try{return JSON.parse(localStorage.getItem(docKey())||"[]")}catch{return []}}
function showNotes(){
 const list=document.getElementById("notesList");list.innerHTML="";
 getNotes().forEach((n,i)=>{const card=document.createElement("div");card.className="item-card";card.textContent=n.text;const meta=document.createElement("small");meta.textContent="Page "+n.page;card.appendChild(meta);list.appendChild(card)});
}
document.getElementById("saveNote").onclick=()=>{
 const text=document.getElementById("noteInput").value.trim();if(!text)return;
 const notes=getNotes();notes.push({page:window.OpenPDF.page,text});localStorage.setItem(docKey(),JSON.stringify(notes));
 document.getElementById("noteInput").value="";showNotes();
};
document.addEventListener("pdf-loaded",showNotes);
