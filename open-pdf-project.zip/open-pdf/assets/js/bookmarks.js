const bookmarkKey=()=> "openpdf-bookmarks-"+(document.getElementById("fileTitle").textContent||"document");
function getBookmarks(){try{return JSON.parse(localStorage.getItem(bookmarkKey())||"[]")}catch{return []}}
function renderBookmarks(){
 const list=document.getElementById("bookmarksList");list.innerHTML="";
 getBookmarks().forEach(p=>{const b=document.createElement("button");b.className="item-card";b.style.width="100%";b.textContent="Page "+p;b.onclick=()=>{document.getElementById("pageNumber").value=p;document.getElementById("pageNumber").dispatchEvent(new Event("change"))};list.appendChild(b)});
}
document.getElementById("bookmarkButton").onclick=()=>{
 const pages=getBookmarks(),p=window.OpenPDF.page;if(!window.OpenPDF.pdf)return;
 if(!pages.includes(p))pages.push(p);localStorage.setItem(bookmarkKey(),JSON.stringify(pages));renderBookmarks();
};
document.addEventListener("pdf-loaded",renderBookmarks);
