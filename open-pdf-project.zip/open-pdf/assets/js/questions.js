const questionKey=()=> "openpdf-questions-"+(document.getElementById("fileTitle").textContent||"document");
function getQuestions(){try{return JSON.parse(localStorage.getItem(questionKey())||"[]")}catch{return []}}
function renderQuestions(){
 const list=document.getElementById("questionsList");list.innerHTML="";
 getQuestions().forEach((q,i)=>{const card=document.createElement("div");card.className="item-card";card.textContent=q.text;const meta=document.createElement("small");meta.textContent="Page "+q.page;card.appendChild(meta);list.appendChild(card)});
}
document.getElementById("addQuestion").onclick=()=>{
 const field=document.getElementById("questionInput"),text=field.value.trim();if(!text)return;
 const qs=getQuestions();qs.push({page:window.OpenPDF.page,text});localStorage.setItem(questionKey(),JSON.stringify(qs));field.value="";renderQuestions();
};
document.addEventListener("pdf-loaded",renderQuestions);
